

#include <iostream>
using namespace std;

int main()
{
	// PROGRAMA PARA PEDIR UNA SUMA COMO ACCESO AL SISTEMA
	int login;
	cout << "Introduce la suma de 5 + 9: ";
	cin >> login;
	//INTRODUCIMOS UN RESULTADO, SI ES CORRECTO ACCEDEMOS AL SISTEMA
	if (login == 14) {
		cout << "\nAcceso correcto";
	}
	else {
		//SI EL RESULTADO ES INCORRECTO, NOS DA LA OPORTUNIDAD DE VOLVER A INTENTARLO
		cout << "\nError, vuelve a intentarlo";
		cout << "\nIntroduce la suma de 5 + 9: ";
		cin >> login;
		if (login == 14) {
			cout << "\nAcceso correcto";
		}
		else {
			//EL RESULTADO HA VUELTO A SER INCORRECTO, TERMINA EL PROGRAMA
			cout << "\Error, fin programa";
		}
	}
}
